ORB GARMENT STUDIO - PROJECT FOLDER TEMPLATE

1. Extract this ZIP.
2. Rename "Project Name" to your project name, for example "Fireside".
3. Put artwork in the matching placement folders. Keep their names unchanged.
4. Drag the renamed project folder into the Artwork library, or use Add folder.
5. Review the import, then use Tags & spots to adjust any preferences.

Import the extracted project folder, not the ZIP. Select the project folder
itself so its name is recognized as the project. Avoid naming the project
"Logos", "Full", or another recognized asset type or placement.

Each placement folder below targets one standard position. Left and right
refer to the person wearing the garment. Unused folders can be deleted.
Empty folders and this text file do not become library assets.

OPTIONAL ASSET TAGS
Inside any placement folder, you can add subfolders named Logos, Wordmarks,
Illustrations, Labels, Symbols, or Textures. Other subfolder names become
custom tags. For example: Fireside/Left Chest/Logos/your-art.svg.
Do not nest one placement folder inside another: their placement rules combine.

MULTIPLE POSITIONS
For flexible artwork, you may add recognized group folders: Full (front and
back), Chest, Sleeves, Wrists, Shoulder Blades, Front Hems, Hood Outside, or
Hood Inside. Anywhere permits all supported placements, including neck tags.
Alternatively, import identical artwork into multiple placement folders:
identical files combine their placement preferences into one library asset.

GARMENT SUPPORT
Hood, pocket, and wrist placements apply to the built-in hoodies. Randomize
uses only positions supported by the selected garment. These folders define
placement preferences, not automatic layer placement or print dimensions.
Use Randomize or add assets manually after importing.

SAVE YOUR COLLECTION
Save a design with Include unused library graphics enabled to preserve the
whole imported collection and its rules in a portable .orb file.

PLACEMENT FOLDERS
- Left Chest
- Right Chest
- Full Front
- Full Back
- Lower Back
- Left Sleeve
- Right Sleeve
- Hoodie Pocket (hoodies)
- Left Hood Outside (hoodies)
- Right Hood Outside (hoodies)
- Left Hood Inside (hoodies)
- Right Hood Inside (hoodies)
- Inside Neck Tag
- Back Neck
- Left Shoulder Blade
- Right Shoulder Blade
- Left Wrist (hoodies)
- Right Wrist (hoodies)
- Left Front Hem
- Right Front Hem
- Center Chest
